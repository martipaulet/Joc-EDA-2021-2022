#define GAME_NAME "Pandemic"
#define VERSION   "1.0"
